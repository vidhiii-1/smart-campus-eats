SMART CAMPUS EATS — LOCAL DEMO

SETUP
1. Download and extract smart_campus_eats.zip.
2. Open the extracted folder in VS Code.
3. Double-click index.html, or right-click it and choose Open with your browser.
4. No installation, API key, framework, or internet connection is required.

FEATURES
- Search by food or canteen name.
- Filter by category, maximum budget, and availability.
- Sort prices low-to-high or high-to-low.
- Compare same/similar dishes, lowest available price, and possible savings.
- Create unique demo queue tokens and track status, queue position, and estimated wait.
- Staff tools to change availability and token status.
- Menu and tokens are saved in this browser using localStorage.

EDIT SAMPLE DATA
1. Open index.html in VS Code.
2. Search for: const canteens = [
   Change canteen names, emoji, or short descriptions there.
3. Search for: const defaultItems = [
   Each menu entry has:
   - id: unique number
   - name: dish name
   - canteen: canteen id from the canteens list
   - price: sample price in rupees (number only)
   - category: Snacks, Meals, Drinks, or Desserts
   - emoji: food emoji
   - status: Available, Low stock, or Sold out
   - similar: shared key used to compare the same/similar dish
4. To compare dishes across canteens, give them the same `similar` value.
5. Save the file and refresh the browser.

IMPORTANT
- Prices and stock are fictional demonstration data, not verified real campus details.
- Staff edits and tokens are stored only in the current browser/device. They are not shared between students.
- Clearing browser site data may clear saved edits/tokens. If you change defaultItems after running the app, existing localStorage data can hide those changes. To load your updated defaults, open browser DevTools > Application > Local Storage and delete keys:
  smartCampusEatsItems_v1
  smartCampusEatsTokens_v1
  Then refresh.
- This is a front-end prototype, not a real ordering system. A production version needs a backend, shared database, staff login, and server-side token management.
